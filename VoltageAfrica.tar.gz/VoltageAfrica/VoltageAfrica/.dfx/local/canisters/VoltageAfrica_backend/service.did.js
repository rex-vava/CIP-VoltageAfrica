export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    'createToken' : IDL.Func([IDL.Nat, IDL.Nat], [IDL.Text], []),
  });
};
export const init = ({ IDL }) => { return []; };
