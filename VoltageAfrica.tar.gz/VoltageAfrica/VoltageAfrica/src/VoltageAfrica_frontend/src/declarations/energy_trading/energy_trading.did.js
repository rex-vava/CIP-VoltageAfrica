
//  mock implementation of the IDL (Interface Description Language)
// for  Energy Trading canister.

export const idlFactory = ({ IDL }) => {
    return IDL.Service({
        'createToken': IDL.Func([IDL.Nat, IDL.Nat], [IDL.Text], []),
        'transferToken': IDL.Func([IDL.Nat, IDL.Principal], [IDL.Text], []),
        'getAvailableTokens': IDL.Func([], [IDL.Vec(IDL.Record({ id: IDL.Nat, owner: IDL.Principal, energyAmount: IDL.Nat, price: IDL.Nat }))], ['query']),
        'buyToken': IDL.Func([IDL.Nat], [IDL.Text], []),
        'registerUser': IDL.Func([IDL.Nat], [IDL.Text], []),
        'getUserBalance': IDL.Func([], [IDL.Nat], ['query']),
    });
};

export const canisterId = "bd3sg-teaaa-aaaaa-qaaba-cai"; // Replace with your actual canister ID

