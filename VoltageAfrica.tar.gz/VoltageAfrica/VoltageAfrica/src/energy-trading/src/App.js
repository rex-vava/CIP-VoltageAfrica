import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Form, Alert } from 'react-bootstrap';
import { Actor, HttpAgent } from '@dfinity/agent';
import { idlFactory } from './path_to_idl'; // Update with the actual path to your IDL

const agent = new HttpAgent({ host: "https://your.ic.network" });
const energyTradingActor = Actor.createActor(idlFactory, { agent, canisterId: "your-canister-id" });

function App() {
    const [userBalance, setUserBalance] = useState(0);
    const [tokens, setTokens] = useState([]);
    const [energyAmount, setEnergyAmount] = useState('');
    const [price, setPrice] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const fetchAvailableTokens = async () => {
        const availableTokens = await energyTradingActor.getAvailableTokens();
        setTokens(availableTokens);
    };

    const createToken = async () => {
        if (!energyAmount || !price) {
            setErrorMessage("Please fill in all fields.");
            return;
        }
        const response = await energyTradingActor.createToken(parseInt(energyAmount), parseInt(price));
        setSuccessMessage(response);
        fetchAvailableTokens();
    };

    const getUserBalance = async () => {
        const balance = await energyTradingActor.getUserBalance();
        setUserBalance(balance);
    };

    useEffect(() => {
        fetchAvailableTokens();
        getUserBalance();
    }, []);

    return (
        <Container>
            <h1 className="mt-4">Smart Energy Trading Platform</h1>
            {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
            {successMessage && <Alert variant="success">{successMessage}</Alert>}
            <Row className="mt-4">
                <Col>
                    <h2>Create Energy Token</h2>
                    <Form>
                        <Form.Group controlId="formEnergyAmount">
                            <Form.Label>Energy Amount (kWh)</Form.Label>
                            <Form.Control 
                                type="number" 
                                placeholder="Enter energy amount" 
                                value={energyAmount} 
                                onChange={(e) => setEnergyAmount(e.target.value)} 
                            />
                        </Form.Group>
                        <Form.Group controlId="formPrice">
                            <Form.Label>Price ($)</Form.Label>
                            <Form.Control 
                                type="number" 
                                placeholder="Enter price" 
                                value={price} 
                                onChange={(e) => setPrice(e.target.value)} 
                            />
                        </Form.Group>
                        <Button variant="primary" onClick={createToken}>Create Token</Button>
                    </Form>
                </Col>
                <Col>
                    <h2>Your Balance: ${userBalance}</h2>
                    <h2>Available Tokens</h2>
                    <ul className="list-group">
                        {tokens.map(token => (
                            <li key={token.id} className="list-group-item">
                                {`ID: ${token.id}, Amount: ${token.energyAmount} kWh, Price: $${token.price}`}
                            </li>
                        ))}
                    </ul>
                </Col>
            </Row>
        </Container>
    );
}

export default App;
